# CardGauge Business V1 — isolated prototype

This is a separate test application. It does not modify the production CardGauge scanner, Render service, GitHub repo, or Supabase.

## Included
- Multi-card photo detection with OpenCV.js
- Batch calls to the existing CardGauge `/api/scan-card` endpoint
- Test inventory with cost, asking price, profit and status
- Test Break Manager with spots, customers, teams and assignment
- Test business dashboard
- Printer-friendly label sheet
- CSV export
- LocalStorage only for test data

## Deploy
Create a NEW Render Static Site from this folder/repository.
Build command: blank
Publish directory: `.`

## Important
The batch scan calls the existing production scanner API for identification/pricing, but this prototype does not write to production Supabase. It does not modify the API.

Test first. Only after approval should we decide how to integrate this into scan.cardgauge.com.
